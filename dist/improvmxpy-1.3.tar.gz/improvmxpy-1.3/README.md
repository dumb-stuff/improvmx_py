###### Badges
[![Build Status](https://app.travis-ci.com/dumb-stuff/improvmx_py.svg?branch=main)](https://app.travis-ci.com/dumb-stuff/improvmx_py) [![Documentation Status](https://readthedocs.org/projects/improvmx-api/badge/?version=latest)](https://improvmx-api.readthedocs.io/en/latest/?badge=latest)
# ImprovMX_PY Repository!
Welcome to this repository!
## Instruction
Please install this through pip (Underdevelopment)
```bash
pip install improvmxpy
```
Or Clone this repo and install it by do
```bash
 git clone https://github.com/dumb-stuff/improvmx_py
 cd improvmx_py
 python  setup.py install
 ```
 this repo is development
###### Also Why I am such an idiot that I forget to add .gitignore D:
### Meme
When I forget to add .gitignore to my local repository
*The size in my PC*
![image](https://user-images.githubusercontent.com/59832159/125052352-124f3e00-e0ce-11eb-9904-c7c15f7b5b22.png)
*Actual Upload*
![image](https://user-images.githubusercontent.com/59832159/125052506-3ca0fb80-e0ce-11eb-8d62-9fb8a255e4f7.png)
##### Please Enjoy my stupidness at this URL
https://github.com/dumb-stuff/improvmx_py/commit/28913ca8340355ffd75478c42b5e696fa12e328b
### DOCUMENTATION!!
https://improvmxpy.tk
# Dumb fact
Every single lines of code in here is get blackked style.
### Update
I added brotlipy to requirements and asynchronous deprecated stuff is removed enjoy it