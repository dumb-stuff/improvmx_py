# Asynchronous classes and function usages
Actually it pretty much same as other stuff but it is async function also it is not blocking you can import and use it like this
```py
import improvmxpy
improvmxpy.asynchronous.your_function_or_class_you_want_to_use
```
But if you use the file not module pretty much all class have Async\<Function_Or_Class_Name\>