# FAQS
**Q: Why It have self error?**
**A: Because you didn't initialize the class**
**Q: Why it say my token is wrong or none?**
**A: You didn't call SetUp class**
**Q: Why it throw error at me that say you need privilage?**
**A: Because API endpoint restrict some feature to subscription!**